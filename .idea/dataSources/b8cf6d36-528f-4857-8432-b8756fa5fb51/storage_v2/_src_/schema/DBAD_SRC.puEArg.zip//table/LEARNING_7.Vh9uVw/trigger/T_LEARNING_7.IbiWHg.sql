create trigger T_LEARNING_7
  before insert
  on LEARNING_7
  for each row
  DECLARE
  BEGIN  SELECT G_LEARNING_7.NEXTVAL INTO :NEW.ID FROM DUAL;
  END T_LEARNING_7;


/

