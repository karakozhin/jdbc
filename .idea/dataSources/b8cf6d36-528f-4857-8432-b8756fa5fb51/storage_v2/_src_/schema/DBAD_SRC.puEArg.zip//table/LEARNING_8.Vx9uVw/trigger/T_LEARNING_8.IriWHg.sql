create trigger T_LEARNING_8
  before insert
  on LEARNING_8
  for each row
  DECLARE
  BEGIN  SELECT G_LEARNING_8.NEXTVAL INTO :NEW.ID FROM DUAL;
  END T_LEARNING_8;


/

