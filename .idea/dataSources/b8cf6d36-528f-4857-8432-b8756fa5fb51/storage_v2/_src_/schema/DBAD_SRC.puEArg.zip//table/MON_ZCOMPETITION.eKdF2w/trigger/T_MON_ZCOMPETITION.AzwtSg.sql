create trigger T_MON_ZCOMPETITION
  before insert
  on MON_ZCOMPETITION
  for each row
  declare
  -- local variables here
begin
  select g_MON_ZCOMPETITION.nextval into :new.id from dual;
end T_MON_ZCOMPETITION;


/

