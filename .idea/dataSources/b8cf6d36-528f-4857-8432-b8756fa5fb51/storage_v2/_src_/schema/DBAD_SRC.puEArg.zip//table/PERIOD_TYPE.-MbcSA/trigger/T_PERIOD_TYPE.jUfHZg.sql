create trigger T_PERIOD_TYPE
  before insert
  on PERIOD_TYPE
  for each row
  DECLARE  
  BEGIN  SELECT G_PERIOD_TYPE.NEXTVAL INTO :NEW.ID FROM DUAL; 
  END T_PERIOD_TYPE;


/

