create trigger T_SOURCE
  before insert
  on SOURCE
  for each row
  DECLARE
  -- local variables here
BEGIN
  SELECT G_SOURCE.NEXTVAL INTO :NEW.ID FROM DUAL;

END T_SOURCE;



/

