create trigger "T_MSH_Head_OVer_Month"
  before insert
  on MSH_HEAD_OVER_MONTH
  for each row
  DECLARE
  BEGIN  SELECT G_MSH_Head_OVer_Month.NEXTVAL INTO :NEW.ID FROM DUAL;
  END T_MSH_Head_OVer_Month;
/

