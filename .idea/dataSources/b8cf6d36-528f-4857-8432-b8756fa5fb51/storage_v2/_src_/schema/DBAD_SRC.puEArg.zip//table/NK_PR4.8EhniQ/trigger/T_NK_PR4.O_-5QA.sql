create trigger T_NK_PR4
  before insert
  on NK_PR4
  for each row
  DECLARE  BEGIN  SELECT G_NK_PR4.NEXTVAL INTO :NEW.ID FROM DUAL;  END T_NK_PR4;


/

