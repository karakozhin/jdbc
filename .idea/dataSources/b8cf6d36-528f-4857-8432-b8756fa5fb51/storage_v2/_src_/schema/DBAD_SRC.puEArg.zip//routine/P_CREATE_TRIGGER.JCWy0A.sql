create procedure P_Create_Trigger(TableName in string) is
pragma autonomous_transaction;
begin
 EXECUTE IMMEDIATE ('  
  CREATE OR REPLACE TRIGGER T_'||TableName||'  
  BEFORE INSERT ON '||TableName||'  FOR EACH ROW
  DECLARE  
  BEGIN  SELECT G_'||TableName||'.NEXTVAL INTO :NEW.ID FROM DUAL; 
  END T_'||TableName||';'); 
  commit;
end P_Create_Trigger;


/

