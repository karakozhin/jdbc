create trigger T_MTSZN_BM
  before insert
  on MTSZN_BM
  for each row
  DECLARE  
  BEGIN  SELECT G_MTSZN_BM.NEXTVAL INTO :NEW.ID FROM DUAL; 
  END T_MTSZN_BM;

/

