create trigger MTSZN_CPS2015_TRG
  before insert
  on MTSZN_CPS2015
  for each row
  begin
  if :new.id is null then
    select MTSZN_CPS2015_seq.nextval into :new.id from dual;
  end if;
end;
/

