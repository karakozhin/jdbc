create trigger T_LEARNING_2_N
  before insert
  on LEARNING_2_N
  for each row
  DECLARE
  BEGIN  SELECT G_LEARNING_2_N.NEXTVAL INTO :NEW.ID FROM DUAL;
  END T_LEARNING_2_N;
/

