create PROCEDURE p_get_space_element_set(  -- Возвращает ID множества элементов пространства. В случае отсутствия записи создает новую по указанным входным параметрам
    p_dimension_arr     IN num_arr,					-- Входные параметры: массив ID элементов измерений(таблица MDIC_DIMENSION), массив ID элементов из ИС Класс (Поле ID из таблицы CLASS_ITEM_TREE_ID), ID пространства(MDIC_SPACE)
    p_item_arr          IN num_arr,					-- Выходной параметр: ID множества элементов пространства.
    p_space_id          IN NUMBER,
    n_space_el_set_id   OUT NUMBER
) IS
    v_dimension_arr     num_arr:= p_dimension_arr;
    v_item_arr          num_arr:= p_item_arr;

    n_temp              NUMBER(32);
    s_search_str        VARCHAR2(4000);
    n_space_element_id  NUMBER(32);
BEGIN
    FOR i IN 1..v_dimension_arr.COUNT - 1 LOOP
        FOR j IN i + 1..v_dimension_arr.COUNT LOOP
            IF v_dimension_arr(i) > v_dimension_arr(j) THEN
                n_temp:= v_dimension_arr(i);
                v_dimension_arr(i):= v_dimension_arr(j);
                v_dimension_arr(j):= n_temp;
                n_temp:= v_item_arr(i);
                v_item_arr(i):= v_item_arr(j);
                v_item_arr(j):= n_temp;
            END IF;
        END LOOP;
    END LOOP;

    FOR i IN 1..v_dimension_arr.COUNT LOOP
        s_search_str:= s_search_str||','||v_dimension_arr(i)||':'||v_item_arr(i);
    END LOOP;
    s_search_str:= SUBSTR(s_search_str, 2, LENGTH(s_search_str));

    BEGIN
        SELECT space_element_set_id
          INTO n_space_el_set_id
          FROM mdic_space_element_set@meta_v2
         WHERE string_id = s_search_str;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            BEGIN
                SELECT mdic_space_element_set_seq.nextval@meta_v2
                  INTO n_space_el_set_id
                  FROM dual;
                INSERT INTO mdic_space_element_set@meta_v2(space_element_set_id, space_id, string_id) VALUES (n_space_el_set_id, p_space_id, s_search_str);
                FOR i IN 1..v_dimension_arr.COUNT LOOP
                    SELECT mdic_space_element_seq.nextval@meta_v2
                      INTO n_space_element_id
                      FROM dual;
                    INSERT INTO mdic_space_element@meta_v2(space_element_id, space_element_set_id, dimension_id, item_id) VALUES (n_space_element_id, n_space_el_set_id, v_dimension_arr(i), v_item_arr(i));
                END LOOP;
            EXCEPTION
                WHEN DUP_VAL_ON_INDEX THEN
                    SELECT space_element_set_id
                      INTO n_space_el_set_id
                      FROM mdic_space_element_set@meta_v2
                     WHERE string_id = s_search_str;
            END;
    END;
EXCEPTION
    WHEN OTHERS THEN
        n_space_el_set_id:= -1;
END p_get_space_element_set;
/

