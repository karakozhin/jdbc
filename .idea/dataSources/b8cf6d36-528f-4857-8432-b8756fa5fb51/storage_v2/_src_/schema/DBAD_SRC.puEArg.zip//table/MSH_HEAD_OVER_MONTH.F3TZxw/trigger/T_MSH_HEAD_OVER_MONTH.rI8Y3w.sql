create trigger T_MSH_HEAD_OVER_MONTH
  before insert
  on MSH_HEAD_OVER_MONTH
  for each row
  DECLARE
  BEGIN  SELECT G_MSH_HEAD_OVER_MONTH.NEXTVAL INTO :NEW.ID FROM DUAL;
  END T_MSH_HEAD_OVER_MONTH;
  --------End Create trigger--------------------------
/

