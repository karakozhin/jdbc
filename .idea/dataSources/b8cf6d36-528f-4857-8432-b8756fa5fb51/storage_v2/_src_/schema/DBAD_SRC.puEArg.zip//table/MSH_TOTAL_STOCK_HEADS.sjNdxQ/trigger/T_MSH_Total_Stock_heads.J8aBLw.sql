create trigger "T_MSH_Total_Stock_heads"
  before insert
  on MSH_TOTAL_STOCK_HEADS
  for each row
  DECLARE
  BEGIN  SELECT G_MSH_Total_Stock_heads.NEXTVAL INTO :NEW.ID FROM DUAL;
  END T_MSH_Total_Stock_heads;
/

