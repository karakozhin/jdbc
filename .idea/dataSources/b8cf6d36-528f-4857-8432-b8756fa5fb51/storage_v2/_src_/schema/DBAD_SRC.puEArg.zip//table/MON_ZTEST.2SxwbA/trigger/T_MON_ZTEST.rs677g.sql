create trigger T_MON_ZTEST
  before insert
  on MON_ZTEST
  for each row
  declare
  -- local variables here
begin
  select g_MON_ZTEST.nextval into :new.id from dual;
end T_MON_ZTEST;


/

