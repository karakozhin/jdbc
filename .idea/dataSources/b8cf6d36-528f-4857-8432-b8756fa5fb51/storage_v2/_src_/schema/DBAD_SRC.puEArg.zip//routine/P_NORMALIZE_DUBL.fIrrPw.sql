create procedure P_NORMALIZE_DUBL is
CURSOR C_CURSOR1 IS select t.f2, t.f1, t.f3,t.f55, t.f41 from MVD_TRANSPORT t 
where t.import_log_id in (601,602,603) group by t.f2, t.f1, t.f3,t.f55, t.f41 having count(*)>1;
V_f2 VARCHAR2(20);
V_f1 DATE;
V_f3 VARCHAR2(50);
V_f55 DATE;
V_f41 VARCHAR2(100);

CURSOR C_CURSOR2 IS SELECT t.f2, t.f1, t.f3,t.f55,t.f41,T.ID,T.IMPORT_LOG_ID FROM MVD_TRANSPORT T 
WHERE T.F1=V_f1 AND TRIM(T.F2)=V_f2 AND TRIM(T.F3)=V_f3 
AND TRIM(T.F41)=V_f41 AND T.F55=V_f55; 

V1_f2 VARCHAR2(20);
V1_f1 DATE;
V1_f3 VARCHAR2(50);
V1_f55 DATE;
V1_f41 VARCHAR2(100);
V1_ID NUMBER;
V1_IMPORT_LOG_ID number;
v_iterator number;
begin
v_iterator:=0;
  OPEN C_CURSOR1;
       LOOP
         FETCH C_CURSOR1 INTO V_F2,V_F1,V_F3,V_F55,V_f41;
         EXIT WHEN C_CURSOR1%NOTFOUND;
         OPEN C_CURSOR2;
              LOOP
               FETCH C_CURSOR2 INTO V1_f2,V1_f1,V1_f3,V1_f55,V1_f41,V1_ID,V1_IMPORT_LOG_ID;
               EXIT WHEN C_CURSOR2%NOTFOUND;
               INSERT INTO MVD_DUBL VALUES(V1_f2,V1_f1,V1_f3,V1_f55,V1_f41,V1_ID,V1_IMPORT_LOG_ID); 
               v_iterator:=v_iterator+1;
               if mod(v_iterator,100)=0 then
                 commit;
               end if;
              END LOOP;
         CLOSE C_CURSOR2;
        END LOOP;
       COMMIT;
  CLOSE C_CURSOR1;
end P_NORMALIZE_DUBL;
/

