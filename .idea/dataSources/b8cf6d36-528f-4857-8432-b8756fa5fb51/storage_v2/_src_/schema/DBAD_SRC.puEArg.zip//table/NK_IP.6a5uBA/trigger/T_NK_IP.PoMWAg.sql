create trigger T_NK_IP
  before insert
  on NK_IP
  for each row
  DECLARE
  BEGIN  SELECT G_NK_IP.NEXTVAL INTO :NEW.ID FROM DUAL;
  END T_NK_IP;


/

