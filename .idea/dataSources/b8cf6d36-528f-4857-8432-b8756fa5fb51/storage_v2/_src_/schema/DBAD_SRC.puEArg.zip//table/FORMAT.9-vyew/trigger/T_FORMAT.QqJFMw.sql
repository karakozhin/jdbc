create trigger T_FORMAT
  before insert
  on FORMAT
  for each row
  declare
  -- local variables here
begin
  select g_format.nextval into :new.id from dual;
end T_FORMAT;



/

