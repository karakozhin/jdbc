create trigger AD_IMPORT_DETAILS_TRG
  before insert
  on AD_IMPORT_DETAILS
  for each row
  begin
  if :new.id is null then
    select ad_import_details_seq.nextval into :new.id from dual;
  end if;
end;
/

