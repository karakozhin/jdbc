create trigger T_MAPPED_VALUE
  before insert
  on MAPPED_VALUE
  for each row
  DECLARE  -- local variables here
 BEGIN  SELECT G_MAPPED_VALUE.NEXTVAL INTO :NEW.ID FROM DUAL;
 END T_MAPPED_VALUE;



/

