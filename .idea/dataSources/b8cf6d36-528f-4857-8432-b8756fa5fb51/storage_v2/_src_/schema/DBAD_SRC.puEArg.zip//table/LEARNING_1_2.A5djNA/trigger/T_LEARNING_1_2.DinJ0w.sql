create trigger T_LEARNING_1_2
  before insert
  on LEARNING_1_2
  for each row
  DECLARE
  BEGIN  SELECT G_LEARNING_1.NEXTVAL INTO :NEW.ID FROM DUAL;
  END T_LEARNING_1_2;


/

