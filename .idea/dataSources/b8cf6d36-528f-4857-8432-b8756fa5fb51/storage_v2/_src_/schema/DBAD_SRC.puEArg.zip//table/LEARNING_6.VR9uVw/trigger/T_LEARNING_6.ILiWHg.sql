create trigger T_LEARNING_6
  before insert
  on LEARNING_6
  for each row
  DECLARE
  BEGIN  SELECT G_LEARNING_6.NEXTVAL INTO :NEW.ID FROM DUAL;
  END T_LEARNING_6;


/

