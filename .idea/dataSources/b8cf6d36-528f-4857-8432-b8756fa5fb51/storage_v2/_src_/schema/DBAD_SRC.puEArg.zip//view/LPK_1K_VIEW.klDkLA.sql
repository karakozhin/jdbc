create view LPK_1K_VIEW as
  select s.id, s.kr, s.inn, s.ud, s.droj, s.fami, s.name, s.otch, s.graj, s.okpo, s.viduz, cat.naim, cat.nviduz, s.gr10, s.gr11, s.gr12, s.gr13, s.gr14, s.gr15, s.gr16, s.gr17, s.gr18, s.gr19, s.year
    from TBBASE s
  LEFT JOIN TBKATALOG cat ON cat.okpo = s.okpo AND cat.bin = s.bin AND s.viduz = cat.viduz
/

