create trigger T_NK_PR14
  before insert
  on NK_PR14
  for each row
  DECLARE  BEGIN  SELECT G_NK_PR14.NEXTVAL INTO :NEW.ID FROM DUAL;  END T_NK_PR14;


/

