create trigger MY_TRIGGER
  before insert
  on TEST_CAR
  for each row
  BEGIN
    SELECT my_seq.NEXTVAL INTO :NEW.ID_CAR FROM dual;
  END;
/

