create trigger T_NK_PR7
  before insert
  on NK_PR7
  for each row
  DECLARE  BEGIN  SELECT G_NK_PR7.NEXTVAL INTO :NEW.ID FROM DUAL;  END T_NK_PR7;


/

