create trigger T_MTSZN_FC
  before insert
  on MTSZN_FC
  for each row
  DECLARE  
  BEGIN  SELECT G_MTSZN_FC.NEXTVAL INTO :NEW.ID FROM DUAL; 
  END T_MTSZN_FC;

/

