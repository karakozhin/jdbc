create trigger T_NK_PR3
  before insert
  on NK_PR3
  for each row
  DECLARE  BEGIN  SELECT G_NK_PR3.NEXTVAL INTO :NEW.ID FROM DUAL;  END T_NK_PR3;


/

