create PROCEDURE p_get_space_instance( -- Возвращает ID пространства(MDIC_SPACE), ID элемента пространства(MDIC_SPACE_INSTANCE) и ID элементов измерений(MDIC_DIMENSION).
    p_acronym_id        IN num_arr,			-- В случае отсутствия искомых записей создаются новые и возвращаются ID вставленных записей
    p_space_id          OUT NUMBER,			-- Входной параметр: массив ID аббревиатур
    p_space_instance_id OUT NUMBER,			-- Выходные параметры: ID пространства, ID элемента пространства, ID элементов измерений
    p_dimension_id      OUT num_arr
) IS
    s_query             VARCHAR2(4000);
    s_from              VARCHAR2(4000);
    s_where             VARCHAR2(4000);
    s_instance_name     VARCHAR2(1000);
    s_decode            VARCHAR2(4000);
    
    n_cursor            INTEGER;
    n_status            INTEGER;
    n_dimension_id      NUMBER(32);
    
    i                   NUMBER(32);
BEGIN
    p_dimension_id:= num_arr();
    p_dimension_id.EXTEND(p_acronym_id.COUNT);
    s_query:= ' SELECT d1.space_instance_id ';
    s_from:= ' FROM mdic_dimension@META_V2 d1 ';
    s_where:= ' WHERE d1.acronym_id = :d1 ';
    s_decode:= ' DECODE(d.acronym_id, '||p_acronym_id(1)||', '||1;
    
    FOR i IN 2..p_acronym_id.COUNT LOOP
        s_decode:= s_decode||', '||p_acronym_id(i)||', '||i;
        s_from:= s_from||', mdic_dimension@META_V2 d'||i;
        s_where:= s_where||' AND d'||i||'.space_instance_id = d1.space_instance_id
                             AND d'||i||'.acronym_id = :d'||i;
    END LOOP;
    s_decode:= s_decode||', 0)';
    s_query:= ' SELECT space_instance_id
                  FROM mdic_dimension@META_V2
                 WHERE space_instance_id = ('||s_query||s_from||s_where||')
                HAVING COUNT(1) = :nCount
                 GROUP BY space_instance_id';
--    dbms_output.put_line(s_query);
--    dbms_output.put_line(s_decode);
    n_cursor:= dbms_sql.open_cursor;
    dbms_sql.parse(n_cursor, s_query, DBMS_SQL.NATIVE);
    FOR i IN 1..p_acronym_id.COUNT LOOP
        dbms_sql.bind_variable(n_cursor, ':d'||i, p_acronym_id(i));
    END LOOP;
    dbms_sql.bind_variable(n_cursor, ':nCount', p_acronym_id.COUNT);
   
    dbms_sql.define_column(n_cursor, 1, p_space_instance_id);
    n_status:= dbms_sql.execute(n_cursor);
    WHILE dbms_sql.fetch_rows(n_cursor) > 0 LOOP
        dbms_sql.column_value(n_cursor, 1, p_space_instance_id); 
    END LOOP;
    dbms_sql.close_cursor(n_cursor);
--    dbms_output.put_line(p_space_instance_id);
    IF p_space_instance_id IS NOT NULL THEN
        i:= 0;
        s_query:= 'SELECT d.dimension_id, '||s_decode||' FROM mdic_dimension@META_V2 d WHERE d.space_instance_id = :p_space_instance_id ORDER BY 2';
        n_cursor:= dbms_sql.open_cursor;
        dbms_sql.parse(n_cursor, s_query, DBMS_SQL.NATIVE);
        dbms_sql.bind_variable(n_cursor, ':p_space_instance_id', p_space_instance_id);

        dbms_sql.define_column(n_cursor, 1, n_dimension_id);
        n_status:= dbms_sql.execute(n_cursor);

        WHILE dbms_sql.fetch_rows(n_cursor) > 0 LOOP
            dbms_sql.column_value(n_cursor, 1, n_dimension_id); 
            i:= i + 1;
            p_dimension_id(i):= n_dimension_id;
        END LOOP;
        dbms_sql.close_cursor(n_cursor);
        SELECT si.space_id
          INTO p_space_id
          FROM mdic_space_instance@META_V2 si
         WHERE si.space_instance_id = p_space_instance_id;
    ELSE
        s_instance_name:= '';
        FOR i IN 1..p_acronym_id.count LOOP
            SELECT s_instance_name||a.name_ru||'-'
              INTO s_instance_name
              FROM mdic_acronym@META_V2 a
             WHERE a.acronym_id = p_acronym_id(i);
        END LOOP;
        s_instance_name:= SUBSTR(s_instance_name, 1, LENGTH(s_instance_name) - 1);
--        dbms_output.put_line(s_instance_name);
        SELECT mdic_space_seq.nextval@META_V2
          INTO p_space_id
          FROM dual;
        INSERT INTO mdic_space@META_V2(
            space_id,
            name_ru,
            dbeg,
            dend,
            crt_date,
            upd_date
        ) VALUES (
            p_space_id,
            s_instance_name,
            TO_DATE('01.01.1990 00:00:00', 'DD-MM-YYYY HH24:MI:SS'),
            TO_DATE('31.12.2012 23:59:59', 'DD-MM-YYYY HH24:MI:SS'),
            SYSDATE,
            SYSDATE
        );
        SELECT mdic_space_instance_seq.nextval@META_V2
          INTO p_space_instance_id
          FROM dual;
        INSERT INTO mdic_space_instance@META_V2(
            space_instance_id,
            space_id,
            sec_examp_name,
            dbeg,
            dend,
            dupd,
            base
        ) VALUES (
            p_space_instance_id,
            p_space_id,
            s_instance_name,
            TO_DATE('01.01.1990 00:00:00', 'DD-MM-YYYY HH24:MI:SS'),
            TO_DATE('31.12.2012 23:59:59', 'DD-MM-YYYY HH24:MI:SS'),
            SYSDATE,
            1
        );
        FOR i IN 1..p_acronym_id.count LOOP
            SELECT mdic_dimension_seq.nextval@META_V2
              INTO p_dimension_id(i)
              FROM dual;
            INSERT INTO mdic_dimension@META_V2(
                dimension_id,
                space_instance_id,
                acronym_id,
                name_alias,
                dbeg,
                dend,
                dupd,
                dcrt
            ) VALUES (
                p_dimension_id(i),
                p_space_instance_id,
                p_acronym_id(i),
                (SELECT a.name_ru FROM mdic_acronym@META_V2 a WHERE a.acronym_id = p_acronym_id(i)),
                TO_DATE('01.01.1990 00:00:00', 'DD-MM-YYYY HH24:MI:SS'),
                TO_DATE('31.12.2012 23:59:59', 'DD-MM-YYYY HH24:MI:SS'),
                SYSDATE,
                SYSDATE
            );
        END LOOP;
    END IF;
EXCEPTION
    WHEN OTHERS THEN
--        dbms_output.put_line(dbms_utility.format_error_backtrace||' - '||dbms_utility.format_error_stack);
        p_space_id:= -1;
        p_space_instance_id:= -1;
END p_get_space_instance;
/

