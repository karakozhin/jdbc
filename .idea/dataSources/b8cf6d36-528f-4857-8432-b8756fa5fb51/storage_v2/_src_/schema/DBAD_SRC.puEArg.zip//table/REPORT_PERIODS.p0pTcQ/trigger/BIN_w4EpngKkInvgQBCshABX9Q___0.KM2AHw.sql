create trigger "BIN$w4EpngKkInvgQBCshABX9Q==$0"
  before insert
  on REPORT_PERIODS
  for each row
  DECLARE  -- local variables here
 BEGIN  SELECT G_REPORT_PERIODS.NEXTVAL INTO :NEW.ID FROM DUAL;
 END T_REPORT_PERIODS;



/

