create trigger T_TEST
  before insert
  on TEST
  for each row
  DECLARE  
  BEGIN  SELECT G_TEST.NEXTVAL INTO :NEW.ID FROM DUAL; 
  END T_TEST;


/

