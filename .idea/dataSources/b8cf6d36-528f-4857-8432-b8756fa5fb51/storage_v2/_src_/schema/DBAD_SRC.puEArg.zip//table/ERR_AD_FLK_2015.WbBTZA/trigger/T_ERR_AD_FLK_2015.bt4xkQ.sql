create trigger T_ERR$AD_FLK_2015
  before insert
  on ERR$AD_FLK_2015
  for each row
  begin
  if :new.id is null then
    select G_ERR$AD_FLK_2015.nextval into :new.id from dual;
  end if;
end;
/

