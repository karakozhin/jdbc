create trigger T_NK_PR8
  before insert
  on NK_PR8
  for each row
  DECLARE  BEGIN  SELECT G_NK_PR8.NEXTVAL INTO :NEW.ID FROM DUAL;  END T_NK_PR8;


/

