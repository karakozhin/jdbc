create trigger T_LEARNING_3_2
  before insert
  on LEARNING_3_2
  for each row
  DECLARE
  BEGIN  SELECT G_LEARNING_3.NEXTVAL INTO :NEW.ID FROM DUAL;
  END T_LEARNING_3_2;


/

