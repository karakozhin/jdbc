create function get_level_code(p_class_version_id number, p_level_code varchar2, p_date date) return varchar2 is
    answ varchar2(30);
BEGIN
  
        SELECT max(level_code)
        INTO   answ
        FROM   DBAD_TRG.CLASS_ITEM_TREE_ID
        WHERE  CLASS_VERSION_ID = p_class_version_id
               and level_code = p_level_code
               and (p_date between beg_date and  nvl(end_date, p_date));
   return answ;
END;
/

