create trigger T_MTSZN_CPS
  before insert
  on MTSZN_CPS
  for each row
  DECLARE  
  BEGIN  SELECT G_MTSZN_CPS.NEXTVAL INTO :NEW.ID FROM DUAL; 
  END T_MTSZN_CPS;

/

