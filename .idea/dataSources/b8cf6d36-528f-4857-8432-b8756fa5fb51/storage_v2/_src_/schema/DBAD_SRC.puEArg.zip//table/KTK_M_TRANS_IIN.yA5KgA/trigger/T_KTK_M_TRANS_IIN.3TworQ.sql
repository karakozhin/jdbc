create trigger T_KTK_M_TRANS_IIN
  before insert
  on KTK_M_TRANS_IIN
  for each row
  declare
  -- local variables here
begin
  select g_KTK_M_TRANS_IIN.nextval into :new.id from dual;
end T_KTK_M_TRANS_IIN;


/

