create procedure P_NORMALIZE_NK_PR14 is

cursor cur_get_info IS
select
  *
FROM nk_pr14 where nk_pr14.is_normalized=0
FOR UPDATE OF nk_pr14.IS_NORMALIZED;

begin


      FOR i IN cur_get_info LOOP

      
      INSERT INTO DBAD_TRG.NK_PR14(
                  iin,
          bin,
          lastname,
          firstname,
          middlename,
          name_yr_liza,
          kod_obl_atnk,
          hislen_rabotnikov_1m_kv,
          hislen_rabotnikov_2m_kv,
          hislen_rabotnikov_3m_kv,
          period,
          tip_subject,
          rnn_yr_liza,
          bin_yr_liza,
          import_log_id,
          src_id
                ) VALUES(
          i.iin,
          i.bin,
          i.lastname,
          i.firstname,
          i.middlename,
          i.name_yr_liza,
          i.kod_obl_atnk,
          TO_NUMBER(i.hislen_rabotnikov_1m_kv, '99999999999999999999999.9999999999999'),
          TO_NUMBER(i.hislen_rabotnikov_2m_kv, '99999999999999999999999.9999999999999'),
          TO_NUMBER(i.hislen_rabotnikov_3m_kv, '99999999999999999999999.9999999999999'),
          i.period,
          i.tip_subject,
          i.rnn_yr_liza,
          i.bin_yr_liza,
          i.import_log_id,
          i.id
        );






      UPDATE nk_pr14
      SET nk_pr14.IS_NORMALIZED = 1
      WHERE CURRENT OF cur_get_info;
      
      END LOOP;

     COMMIT;

end P_NORMALIZE_NK_PR14;
/

