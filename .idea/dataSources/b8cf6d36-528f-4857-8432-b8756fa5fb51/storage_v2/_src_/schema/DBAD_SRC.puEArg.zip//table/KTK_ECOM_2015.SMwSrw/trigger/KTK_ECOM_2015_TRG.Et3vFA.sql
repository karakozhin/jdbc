create trigger KTK_ECOM_2015_TRG
  before insert
  on KTK_ECOM_2015
  for each row
  begin
  if :new.id is null then
    select KTK_ECOM_2015_seq.nextval into :new.id from dual;
  end if;
end;
/

