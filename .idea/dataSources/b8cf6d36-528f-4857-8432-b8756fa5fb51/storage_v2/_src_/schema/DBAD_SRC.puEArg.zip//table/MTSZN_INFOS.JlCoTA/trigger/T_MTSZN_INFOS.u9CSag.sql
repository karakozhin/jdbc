create trigger T_MTSZN_INFOS
  before insert
  on MTSZN_INFOS
  for each row
  DECLARE  
  BEGIN  SELECT G_MTSZN_INFOS.NEXTVAL INTO :NEW.ID FROM DUAL; 
  END T_MTSZN_INFOS;

/

