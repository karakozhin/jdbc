create procedure p_normalize_ad_flk(p_import_log_id number)
/* created by: a.kussein
  * 2 параметра входных
  * 1 это import_lod_id
  * 2 - дата для класса в формате dd.mm.yyyy
*/
       is
       new_row AD_FLK_2015%ROWTYPE;
       n number:= 0;
       v_count number := 0;
       nsiG011 number := 0;
       v_date date;
BEGIN
  v_date := to_date('01.01.2015','DD.MM.YYYY');
  FOR i IN (
    select
          t.id,
          kato,
          g33,
          nd,
          g32,
          g11,
          g34,
          g011,
          stran,
          g251,
          translate(g38,'.',',') t38,
          translate(g315a,'.',',') t315a,
          translate(g46,'.',',') t46,
          import_log_id,
          get_level_code(213, kato||'0000000', v_date) kato_level_code,
          get_level_code(2080, g33, v_date) g33_level_code,
          get_level_code(2394, g11, v_date) g11_level_code,
          get_level_code(2394, g34, v_date) g34_level_code,
          get_level_code(2394, stran, v_date) stran_level_code,
          get_level_code(2210, g251, v_date) g251_level_code,
          rate course
    FROM  dbad_src.KTK_ECOM_2015 t,
          DBAD_SRC.IMPORT_LOG t1,
          DBAD_TRG.EXCHANGEMONEY t2,
          DBAD_SRC.REPORT_PERIODS t3
    WHERE t.IMPORT_LOG_ID = t1.id
          and t1.REPORT_PERIODS_ID = t3.id
          and t2.PERIOD >= t3.DATA_BEGIN
          and t2.period <= t3.DATA_END
          and t.import_log_id = p_import_log_id )

    LOOP
      new_row:= NULL;
      new_row.kato := i.kato_level_code;
      new_row.g33 := i.g33_level_code;
      new_row.g11 := i.g11_level_code;
      new_row.g34 := i.g34_level_code;
      new_row.g011 := i.g011;
      new_row.stran := i.stran_level_code;
      new_row.g251 := i.g251;
      new_row.import_log_id := i.import_log_id;
      new_row.dirty_id := i.id;
      new_row.replace_number :=0;
      new_row.g38 := i.t38;
      new_row.g315a := i.t315a;
      new_row.g46 := i.t46;
      new_row.g46_tg := i.t46 * i.course;

      BEGIN
        SELECT level_code
        INTO   new_row.g011
        FROM   DBAD_TRG.CLASS_ITEM_TREE_ID
        WHERE  CLASS_VERSION_ID=4314
               and     VRNAME like '%'||LOWER(i.g011)||'%'
               and     (v_date
               between beg_date
               and     nvl(end_date,v_date));
        EXCEPTION
               WHEN OTHERS THEN
               nsiG011 := 123; -- 8 прочие
      END;

      BEGIN
        SELECT count(*)
        INTO   v_count
        FROM   AD_FLK_2015
        WHERE  dirty_id = i.id;
        IF (v_count > 0) then
          UPDATE AD_FLK_2015
          SET    replace_number = replace_number + 1
          WHERE  dirty_id = i.id;
        ELSIF(i.kato IS null or i.g33 IS null or i.g11 IS null or i.g34 IS null or i.g011 IS null or i.stran IS null or
          i.g251 IS null or i.t38 IS null or i.t315a IS null or i.t46 IS null) then
          INSERT INTO DBAD_SRC.ERR$AD_FLK_2015 (ERR_MESG, KATO, G33, G11, G34, G011, STRAN, G251, G38, G315A, G46, G46_TG,
                                               IMPORT_LOG_ID,KTK_ECOM_2015_ID,G32,ND)
          VALUES ('Не прошел проверку на ноль', i.kato, i.g33, i.g11, i.g34, i.g011, i.stran, i.g251,
                 i.t38, i.t315a, i.t46, i.t46 * i.course, i.import_log_id,i.id,i.g32,i.nd);
        ELSIF (i.kato_level_code is null) then
          INSERT INTO DBAD_SRC.ERR$AD_FLK_2015 (ERR_MESG, KATO, G33, G11, G34, G011, STRAN, G251, G38, G315A, G46, G46_TG,
                                               IMPORT_LOG_ID,NSI_COLUMN,KTK_ECOM_2015_ID,G32,ND)
          VALUES ('Не прошел проверку на НСИ', i.kato, i.g33, i.g11, i.g34, i.g011, i.stran, i.g251,
                 i.t38, i.t315a, i.t46, i.t46 * i.course, i.import_log_id,'kato',i.id,i.g32,i.nd);
        ELSIF (i.g33_level_code is null) then
          INSERT INTO DBAD_SRC.ERR$AD_FLK_2015 (ERR_MESG, KATO, G33, G11, G34, G011, STRAN, G251, G38, G315A, G46, G46_TG,
                                               IMPORT_LOG_ID,NSI_COLUMN,KTK_ECOM_2015_ID,G32,ND)
          VALUES ('Не прошел проверку на НСИ', i.kato, i.g33, i.g11, i.g34, i.g011, i.stran, i.g251,
                 i.t38, i.t315a, i.t46, i.t46 * i.course, i.import_log_id,'g33',i.id,i.g32,i.nd);
        ELSIF (i.g11_level_code is null) then
          INSERT INTO DBAD_SRC.ERR$AD_FLK_2015 (ERR_MESG, KATO, G33, G11, G34, G011, STRAN, G251, G38, G315A, G46, G46_TG,
                                               IMPORT_LOG_ID,NSI_COLUMN,KTK_ECOM_2015_ID,G32,ND)
          VALUES ('Не прошел проверку на НСИ', i.kato, i.g33, i.g11, i.g34, i.g011, i.stran, i.g251,
                 i.t38, i.t315a, i.t46, i.t46 * i.course, i.import_log_id,'g11',i.id,i.g32,i.nd);
        ELSIF (i.g34_level_code is null) then
          INSERT INTO DBAD_SRC.ERR$AD_FLK_2015 (ERR_MESG, KATO, G33, G11, G34, G011, STRAN, G251, G38, G315A, G46, G46_TG,
                                               IMPORT_LOG_ID,NSI_COLUMN,KTK_ECOM_2015_ID,G32,ND)
          VALUES ('Не прошел проверку на НСИ', i.kato, i.g33, i.g11, i.g34, i.g011, i.stran, i.g251,
                 i.t38, i.t315a, i.t46, i.t46 * i.course, i.import_log_id,'g34',i.id,i.g32,i.nd);
        ELSIF (nsiG011 = 123) then
          INSERT INTO DBAD_SRC.ERR$AD_FLK_2015 (ERR_MESG, KATO, G33, G11, G34, G011, STRAN, G251, G38, G315A, G46, G46_TG,
                                               IMPORT_LOG_ID,NSI_COLUMN,KTK_ECOM_2015_ID,G32,ND)
          VALUES ('Не прошел проверку на НСИ', i.kato, i.g33, i.g11, i.g34, i.g011, i.stran, i.g251,
                 i.t38, i.t315a, i.t46, i.t46 * i.course, i.import_log_id,'g011',i.id,i.g32,i.nd);
        ELSIF (i.stran_level_code is null) then
          INSERT INTO DBAD_SRC.ERR$AD_FLK_2015 (ERR_MESG, KATO, G33, G11, G34, G011, STRAN, G251, G38, G315A, G46, G46_TG,
                                               IMPORT_LOG_ID,NSI_COLUMN,KTK_ECOM_2015_ID,G32,ND)
          VALUES ('Не прошел проверку на НСИ', i.kato, i.g33, i.g11, i.g34, i.g011, i.stran, i.g251,
                 i.t38, i.t315a, i.t46, i.t46 * i.course, i.import_log_id,'stran',i.id,i.g32,i.nd);
        ELSIF (i.g251_level_code is null) then
          INSERT INTO DBAD_SRC.ERR$AD_FLK_2015 (ERR_MESG, KATO, G33, G11, G34, G011, STRAN, G251, G38, G315A, G46, G46_TG,
                                               IMPORT_LOG_ID,NSI_COLUMN,KTK_ECOM_2015_ID,G32,ND)
          VALUES ('Не прошел проверку на НСИ', i.kato, i.g33, i.g11, i.g34, i.g011, i.stran, i.g251,
                 i.t38, i.t315a, i.t46, i.t46 * i.course, i.import_log_id,'g251',i.id,i.g32,i.nd);
        ELSIF (i.g34_level_code is null or i.g34_level_code = 0 or i.g34_level_code = 'EU') then
          new_row.g34 := i.g11_level_code;
        ELSE
          INSERT INTO AD_FLK_2015 VALUES new_row;
          UPDATE AD_FLK_2015
          SET    replace_number = 0
          WHERE  dirty_id = i.id;
        end if;
      END;
      if (n = 1000) then
        commit;
        n := 0;
      else
        n := n + 1;
        end if;
     END LOOP;
     COMMIT;
end p_normalize_ad_flk;
/

