create trigger T_AD_FLK_2015
  before insert
  on AD_FLK_2015
  for each row
  begin
  if :new.id is null then
    select G_AD_FLK_2015.nextval into :new.id from dual;
  end if;
end;
/

