create trigger T_MTSZN_CPS2016
  before insert
  on MTSZN_CPS2016
  for each row
  begin
  if :new.id is null then
    select G_MTSZN_CPS2016.nextval into :new.id from dual;
  end if;
end;
/

