create procedure p_learning_3_2(p_import_log_id number, p_date varchar2(100)) is
  new_row DBAD_TRG.learning_3_2%ROWTYPE;
  n number:= 0;
  g_date date;
begin
  g_date := to_date(p_date,'DD.MM.YYYY');
  FOR i IN (
    select
          ID,
          trim(IIN) t_iin,
          trim(FNAME) t_fname,
          trim(LNAME) t_lname,
          trim(MNAME) t_mname,
          trim(DATE_BIRTH) t_birth,
          F_210,
          get_level_code(41, F_210, g_date) f_210_level_code,
          IMPORT_LOG_ID
    FROM  dbad_src.LEARNING_3_2 t
    WHERE import_log_id = p_import_log_id
  )
  LOOP
      new_row:= NULL;
      new_row.DIRTY_ID := i.ID;
      new_row.IIN := i.t_iin;
      new_row.FNAME := i.t_fname;
      new_row.LNAME := i.t_lname;
      new_row.MNAME := i.t_mname;
      new_row.DATE_BIRTH := i.t_birth;
      new_row.F_210 := i.F_210;
      new_row.IMPORT_LOG_ID := i.IMPORT_LOG_ID;
      new_row.F_210_TYPE := null;

      BEGIN
        if(i.t_fname is null or i.t_fname = '-' or i.t_fname = 'null'
                     or i.t_lname is null or i.t_lname = '-' or i.t_lname = 'null'
                     or i.t_birth is null or i.t_birth = '-' or i.t_birth = 'null'
                     or i.F_210 is null or i.F_210 = '-' or i.F_210 = 'null') then
          UPDATE DBAD_SRC.LEARNING_3_2 SET STATUS_ID = 2, CODE_ID = 1 WHERE ID=i.ID;
        ELSIF(i.f_210_level_code is null) then
          UPDATE DBAD_SRC.LEARNING_3_2 SET STATUS_ID = 2, CODE_ID = 2 WHERE ID=i.ID;
        ELSE
          if(length(i.t_iin) = 12) then
            new_row.IIN := i.t_iin;
          ELSE
            new_row.IIN := null;
          END IF;
          SELECT VRNAME
          INTO   new_row.F_210_TYPE
          FROM   DBAD_TRG.CLASS_ITEM_TREE_ID
          WHERE  CLASS_VERSION_ID = 41
                 and level_code = i.f_210_level_code
                 and (to_date(g_date,'DD.MM.YYYY') between beg_date
                 and nvl(end_date,to_date(g_date,'DD.MM.YYYY')));
          INSERT INTO DBAD_TRG.learning_3_2 VALUES new_row;
        END IF;
      END;
     if (n = 1000) then
        COMMIT;
        n := 0;
      else
        n := n + 1;
        end if;
     END LOOP;
     COMMIT;
end p_learning_3_2;
/

