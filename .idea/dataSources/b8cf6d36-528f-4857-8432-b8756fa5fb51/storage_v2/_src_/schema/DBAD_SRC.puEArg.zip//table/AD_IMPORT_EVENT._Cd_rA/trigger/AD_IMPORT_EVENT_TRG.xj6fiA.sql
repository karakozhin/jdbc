create trigger AD_IMPORT_EVENT_TRG
  before insert
  on AD_IMPORT_EVENT
  for each row
  begin
  if :new.id is null then
    select ad_import_event_seq.nextval into :new.id from dual;
  end if;
end;
/

