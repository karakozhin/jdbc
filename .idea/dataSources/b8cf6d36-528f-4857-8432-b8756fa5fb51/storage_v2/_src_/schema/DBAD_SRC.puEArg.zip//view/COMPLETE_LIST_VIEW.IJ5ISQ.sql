create view COMPLETE_LIST_VIEW as
  select s."KR",s."NN",s."BIN",s."OKPO",s."VIDUZ",s."OBL",s."TE",s."INN",s."UD",s."DROJ",s."FAMI",s."NAME",s."OTCH",s."POL",s."GRAJ",s."GR10",s."GR11",s."GR12",s."GR13",s."GR14",s."GR15",s."GR16",s."GR17",s."GR18",s."GR19",s."YEAR", cat.naim, cat.nviduz
    from TBBASE s
  LEFT JOIN TBKATALOG cat ON cat.okpo = s.okpo AND cat.bin = s.bin
/

