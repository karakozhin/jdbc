create procedure P_NORMALIZE_KTK_TEMP_FLK(import_log_id number) is  -- ?????????? ??????? import_log_id ? ??????? ? ???? ??????? ? INSERT'e

usd_rate REAL;

cursor cur_get_info IS
select
  ID,
  g011,
  kato,
  g11,
  g15a,
  g17a,
  stran,
  g251,
  g33,
  g34,
  IMPORT_LOG_ID
FROM KTK_ECOM_TEMP1 t where t.import_log_id = import_log_id;




TYPE T_KTK_TAB  IS TABLE OF cur_get_info%ROWTYPE INDEX BY binary_integer;

l_info_list T_KTK_TAB;

begin



  DBMS_OUTPUT.enable;
  DBMS_OUTPUT.put_line('Hello world');
/*execute immediate 'alter table KTK_FLK drop constraint FOR1';
execute immediate 'alter table KTK_FLK drop constraint FOR2';
execute immediate 'alter table KTK_FLK drop constraint FOR3';
execute immediate 'alter table KTK_FLK drop constraint FOR4';
execute immediate 'alter table KTK_FLK drop constraint FOR5';
execute immediate 'alter table KTK_FLK drop constraint FOR6';
execute immediate 'alter table KTK_FLK drop constraint FOR7';

execute immediate 'drop table CLASS_KTK_TEMP_4314';
execute immediate 'drop table CLASS_KTK_TEMP_213';
execute immediate 'drop table CLASS_KTK_TEMP_2394';
execute immediate 'drop table CLASS_KTK_TEMP_2210';
execute immediate 'drop table CLASS_KTK_TEMP_2080';*/
/*
execute immediate 'CREATE TABLE CLASS_KTK_TEMP_4314 AS SELECT trim(LEVEL_CODE) AS LEVEL_CODE, ID FROM class_item_tree_id@class_44 t where t.class_version_id=4314 and t.end_date is null';
execute immediate 'CREATE TABLE CLASS_KTK_TEMP_213 AS SELECT trim(LEVEL_CODE) AS LEVEL_CODE, ID FROM class_item_tree_id@class_44 t where t.class_version_id=213 and t.end_date is null';
execute immediate 'CREATE TABLE CLASS_KTK_TEMP_2394 AS SELECT trim(LEVEL_CODE) AS LEVEL_CODE, ID FROM class_item_tree_id@class_44 t where t.class_version_id=2394 and t.end_date is null';
execute immediate 'CREATE TABLE CLASS_KTK_TEMP_2210 AS SELECT trim(LEVEL_CODE) AS LEVEL_CODE, ID FROM class_item_tree_id@class_44 t where t.class_version_id=2210 and t.end_date is null';
execute immediate 'CREATE TABLE CLASS_KTK_TEMP_2080 AS SELECT trim(LEVEL_CODE) AS LEVEL_CODE, ID FROM class_item_tree_id@class_44 t where t.class_version_id=2080 and t.end_date is null';

execute immediate 'alter table CLASS_KTK_TEMP_4314 add constraint PRIM_KTK_TEMP_4314 primary key (LEVEL_CODE)';
execute immediate 'alter table CLASS_KTK_TEMP_213 add constraint PRIM_KTK_TEMP_213 primary key (LEVEL_CODE)';
execute immediate 'alter table CLASS_KTK_TEMP_2394 add constraint PRIM_KTK_TEMP_2394 primary key (LEVEL_CODE)';
execute immediate 'alter table CLASS_KTK_TEMP_2210 add constraint PRIM_KTK_TEMP_2210 primary key (LEVEL_CODE)';
execute immediate 'alter table CLASS_KTK_TEMP_2080 add constraint PRIM_KTK_TEMP_2080 primary key (LEVEL_CODE)';
*/
/*
--execute immediate 'alter table KTK_TEMP_FLK add constraint FOR_KTK_TEMP1 foreign key (g011) references CLASS_KTK_TEMP_4314 (LEVEL_CODE)';
execute immediate 'alter table KTK_TEMP_FLK add constraint FOR_KTK_TEMP2 foreign key (kato) references CLASS_KTK_TEMP_213 (LEVEL_CODE)';
execute immediate 'alter table KTK_TEMP_FLK add constraint FOR_KTK_TEMP3 foreign key (G11) references CLASS_KTK_TEMP_2394 (LEVEL_CODE)';
execute immediate 'alter table KTK_TEMP_FLK add constraint FOR_KTK_TEMP4 foreign key (g15a) references CLASS_KTK_TEMP_2394 (LEVEL_CODE)';
execute immediate 'alter table KTK_TEMP_FLK add constraint FOR_KTK_TEMP5 foreign key (g17a) references CLASS_KTK_TEMP_2394 (LEVEL_CODE)';
execute immediate 'alter table KTK_TEMP_FLK add constraint FOR_KTK_TEMP6 foreign key (STRAN) references CLASS_KTK_TEMP_2394 (LEVEL_CODE)';
execute immediate 'alter table KTK_TEMP_FLK add constraint FOR_KTK_TEMP7 foreign key (g33) references CLASS_KTK_TEMP_2080 (LEVEL_CODE)';
execute immediate 'alter table KTK_TEMP_FLK add constraint FOR_KTK_TEMP8 foreign key (g34) references CLASS_KTK_TEMP_2394 (LEVEL_CODE)';
execute immediate 'alter table KTK_TEMP_FLK add constraint FOR_KTK_TEMP9 foreign key (g251) references CLASS_KTK_TEMP_2210 (LEVEL_CODE)';
*/
/*
select rate into usd_rate from mdic_usd_rate@meta_v2 d
         where d.period like CONCAT(
              CONCAT(CONCAT('%',TO_CHAR(
                        (select data_begin from report_periods f1
                                 where f1.id in (select report_periods_id from import_log t where t.id = IMP_LOG_ID)
                        ),
                        'MM')),
                     '.'),
                     TO_CHAR(
                        (select data_begin from report_periods f2
                                where f2.id in (select report_periods_id from import_log t where t.id = IMP_LOG_ID)
                        ),
                        'YY'
                     )
);
*/

     open cur_get_info;
      loop
       fetch cur_get_info bulk collect into l_info_list limit 10000;
       exit when (cur_get_info%NOTFOUND AND l_info_list.count() <= 0);

      FORALL INDX IN L_INFO_LIST.FIRST .. L_INFO_LIST.LAST
       INSERT INTO KTK_TEMP_FLK(
    ID,
  g011,
  kato,
  g11,
  g15a,
  g17a,
  stran,
  g251,
  g33,
  g34,
  IMPORT_LOG_ID
  
                ) VALUES(
                /*L_INFO_LIST(INDX).ID,
                RPAD(trim(L_INFO_LIST(INDX).KATO),9,'0'),
                trim(L_INFO_LIST(INDX).G33),
                trim(L_INFO_LIST(INDX).G11),
                trim(L_INFO_LIST(INDX).G34),
                --DECODE(trim(L_INFO_LIST(INDX).G011),'??',2,'??',1),
        trim(L_INFO_LIST(INDX).G011),
                trim(L_INFO_LIST(INDX).STRAN),
                trim(L_INFO_LIST(INDX).G251),
        trim(L_INFO_LIST(INDX).g33),
        trim(L_INFO_LIST(INDX).g34),
                L_INFO_LIST(INDX).IMPORT_LOG_ID)*/
                L_INFO_LIST(INDX).ID,
  trim(L_INFO_LIST(INDX).g011),
  RPAD(trim(L_INFO_LIST(INDX).KATO),9,'0'),
  trim(L_INFO_LIST(INDX).g11),
  trim(L_INFO_LIST(INDX).g15a),
  trim(L_INFO_LIST(INDX).g17a),
  trim(L_INFO_LIST(INDX).stran),
  trim(L_INFO_LIST(INDX).g251),
  trim(L_INFO_LIST(INDX).g33),
  trim(L_INFO_LIST(INDX).g34),
  L_INFO_LIST(INDX).IMPORT_LOG_ID)
                LOG ERRORS INTO ERR$_KTK_TEMP_FLK REJECT LIMIT UNLIMITED;
      END LOOP;

    --  update KTK_ECOM set kato=null where id in (select id from cur_get_info);

     CLOSE cur_get_info;
     COMMIT;

end P_NORMALIZE_KTK_TEMP_FLK;
/

