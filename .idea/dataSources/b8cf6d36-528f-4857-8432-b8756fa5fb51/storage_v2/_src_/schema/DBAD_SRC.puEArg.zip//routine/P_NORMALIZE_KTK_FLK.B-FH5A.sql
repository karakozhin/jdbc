create procedure P_NORMALIZE_KTK_FLK(IMP_LOG_ID IN NUMBER) is  -- ���������� ������� import_log_id � ������� � ���� ������� � INSERT'e

usd_rate REAL;

cursor cur_get_info IS
select
  ID,
  KATO,
  G33,
  G11,
  G34,
  G011,
  STRAN,
  G251,
  G38,
  G315A,
  G46,
  IMPORT_LOG_ID
FROM KTK_ECOM_2015 t where t.IMPORT_LOG_ID=11650;




TYPE T_KTK_TAB  IS TABLE OF cur_get_info%ROWTYPE INDEX BY binary_integer;

l_info_list T_KTK_TAB;

begin



  DBMS_OUTPUT.enable;
  DBMS_OUTPUT.put_line('Hello world');
execute immediate 'alter table KTK_FLK drop constraint FOR1';
execute immediate 'alter table KTK_FLK drop constraint FOR2';
execute immediate 'alter table KTK_FLK drop constraint FOR3';
execute immediate 'alter table KTK_FLK drop constraint FOR4';
execute immediate 'alter table KTK_FLK drop constraint FOR5';
execute immediate 'alter table KTK_FLK drop constraint FOR6';
execute immediate 'alter table KTK_FLK drop constraint FOR7';

execute immediate 'drop table CLASS_KATO_LEVEL_CODES';
execute immediate 'drop table CLASS_KS_LEVEL_CODES';
execute immediate 'drop table CLASS_KVT_LEVEL_CODES';
execute immediate 'drop table CLASS_SEI_LEVEL_CODES';
execute immediate 'drop table CLASS_TNVED_LEVEL_CODES';

execute immediate 'CREATE TABLE CLASS_KATO_LEVEL_CODES AS SELECT trim(LEVEL_CODE) AS LEVEL_CODE, ID FROM class_item_tree_id@class_44 t where t.class_version_id=213 and t.end_date is null';
execute immediate 'CREATE TABLE CLASS_KS_LEVEL_CODES AS SELECT trim(LEVEL_CODE) AS LEVEL_CODE, ID FROM class_item_tree_id@class_44 t where t.class_version_id=2394 and t.end_date is null';
execute immediate 'CREATE TABLE CLASS_KVT_LEVEL_CODES AS SELECT trim(LEVEL_CODE) AS LEVEL_CODE, ID FROM class_item_tree_id@class_44 t where t.class_version_id=2210 and t.end_date is null';
execute immediate 'CREATE TABLE CLASS_SEI_LEVEL_CODES AS SELECT trim(LEVEL_CODE) AS LEVEL_CODE, ID FROM class_item_tree_id@class_44 t where t.class_version_id=4314 and t.end_date is null';
execute immediate 'CREATE TABLE CLASS_TNVED_LEVEL_CODES AS SELECT trim(LEVEL_CODE) AS LEVEL_CODE, ID FROM class_item_tree_id@class_44 t where t.class_version_id=2080 and t.end_date is null';

execute immediate 'alter table CLASS_KATO_LEVEL_CODES add constraint PRIM_KATO primary key (LEVEL_CODE)';
execute immediate 'alter table CLASS_KS_LEVEL_CODES add constraint PRIM_KS primary key (LEVEL_CODE)';
execute immediate 'alter table CLASS_KVT_LEVEL_CODES add constraint PRIM_KVT primary key (LEVEL_CODE)';
execute immediate 'alter table CLASS_SEI_LEVEL_CODES add constraint PRIM_SEI primary key (LEVEL_CODE)';
execute immediate 'alter table CLASS_TNVED_LEVEL_CODES add constraint PRIM_TNVED primary key (LEVEL_CODE)';

execute immediate 'alter table KTK_FLK add constraint FOR1 foreign key (KATO) references class_kato_level_codes (LEVEL_CODE)';
execute immediate 'alter table KTK_FLK add constraint FOR2 foreign key (G33) references class_tnved_level_codes (LEVEL_CODE)';
execute immediate 'alter table KTK_FLK add constraint FOR3 foreign key (G11) references class_ks_level_codes (LEVEL_CODE)';
execute immediate 'alter table KTK_FLK add constraint FOR4 foreign key (G34) references class_ks_level_codes (LEVEL_CODE)';
execute immediate 'alter table KTK_FLK add constraint FOR5 foreign key (G011) references class_sei_level_codes (LEVEL_CODE)';
execute immediate 'alter table KTK_FLK add constraint FOR6 foreign key (STRAN) references class_ks_level_codes (LEVEL_CODE)';
execute immediate 'alter table KTK_FLK add constraint FOR7 foreign key (G251) references class_kvt_level_codes (LEVEL_CODE)';

select rate into usd_rate from mdic_usd_rate@meta_v2 d
         where d.period like CONCAT(
              CONCAT(CONCAT('%',TO_CHAR(
                        (select data_begin from report_periods f1
                                 where f1.id in (select report_periods_id from import_log t where t.id = IMP_LOG_ID)
                        ),
                        'MM')),
                     '.'),
                     TO_CHAR(
                        (select data_begin from report_periods f2
                                where f2.id in (select report_periods_id from import_log t where t.id = IMP_LOG_ID)
                        ),
                        'YY'
                     )
);

     open cur_get_info;
      loop
       fetch cur_get_info bulk collect into l_info_list limit 1000;
       exit when (cur_get_info%NOTFOUND AND l_info_list.count() <= 0);

      FORALL INDX IN L_INFO_LIST.FIRST .. L_INFO_LIST.LAST
       INSERT INTO DBAD_TRG.KTK_ECOM_2015(
                ID,
        KATO,
        G33,
        G11,
        G34,
        G011,
        STRAN,
        G251,
        G38,
        G315A,
        G46,
        G46_TG,
        IMPORT_LOG_ID
                ) VALUES(
                L_INFO_LIST(INDX).ID,
                RPAD(trim(L_INFO_LIST(INDX).KATO),9,'0'),
                trim(L_INFO_LIST(INDX).G33),
                trim(L_INFO_LIST(INDX).G11),
                trim(L_INFO_LIST(INDX).G34),
                DECODE(trim(L_INFO_LIST(INDX).G011),'��',2,'��',1),
                trim(L_INFO_LIST(INDX).STRAN),
                trim(L_INFO_LIST(INDX).G251),
                TO_NUMBER(replace(L_INFO_LIST(INDX).G38,'.',',')),
                TO_NUMBER(replace(L_INFO_LIST(INDX).G315A,'.',',')),
                TO_NUMBER(replace(L_INFO_LIST(INDX).G46,'.',',')),
                TO_NUMBER(replace(L_INFO_LIST(INDX).G46,'.',','))*usd_rate,
                L_INFO_LIST(INDX).IMPORT_LOG_ID)
                LOG ERRORS INTO ERR$_KTK_FLK REJECT LIMIT UNLIMITED;
      END LOOP;

    --  update KTK_ECOM set kato=null where id in (select id from cur_get_info);

     CLOSE cur_get_info;
     COMMIT;

end P_NORMALIZE_KTK_FLK;
/

