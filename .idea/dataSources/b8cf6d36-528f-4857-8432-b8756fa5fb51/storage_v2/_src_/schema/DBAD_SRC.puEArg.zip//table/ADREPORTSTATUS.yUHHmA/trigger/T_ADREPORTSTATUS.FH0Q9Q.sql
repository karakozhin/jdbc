create trigger T_ADREPORTSTATUS
  before insert
  on ADREPORTSTATUS
  for each row
  begin
  if :new.id is null then
    select G_ADREPORTSTATUS.nextval into :new.id from dual;
  end if;
end;
/

