create trigger T_LEARNING_2
  before insert
  on LEARNING_2
  for each row
  DECLARE
  BEGIN  SELECT G_LEARNING_2.NEXTVAL INTO :NEW.ID FROM DUAL;
  END T_LEARNING_2;


/

