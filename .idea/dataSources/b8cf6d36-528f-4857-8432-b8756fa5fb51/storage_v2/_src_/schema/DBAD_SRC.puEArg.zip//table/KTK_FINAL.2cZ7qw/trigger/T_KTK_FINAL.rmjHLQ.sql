create trigger T_KTK_FINAL
  before insert
  on KTK_FINAL
  for each row
  DECLARE
  BEGIN  SELECT G_KTK_FINAL.NEXTVAL INTO :NEW.ID FROM DUAL;
  END T_KTK_FINAL;


/

