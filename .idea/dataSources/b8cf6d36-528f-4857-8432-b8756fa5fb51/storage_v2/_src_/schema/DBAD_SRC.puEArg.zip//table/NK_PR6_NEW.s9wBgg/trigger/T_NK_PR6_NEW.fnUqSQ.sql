create trigger T_NK_PR6_NEW
  before insert
  on NK_PR6_NEW
  for each row
  DECLARE  -- local variables here
 BEGIN  SELECT G_NK_PR6_NEW.NEXTVAL INTO :NEW.ID FROM DUAL;
 END T_NK_PR6_NEW;


/

