create trigger T_NK_PR2_12
  before insert
  on NK_PR2_12
  for each row
  DECLARE
  BEGIN  SELECT G_nk_pr2_12.NEXTVAL INTO :NEW.ID FROM DUAL;
  END T_nk_pr2_12;


/

