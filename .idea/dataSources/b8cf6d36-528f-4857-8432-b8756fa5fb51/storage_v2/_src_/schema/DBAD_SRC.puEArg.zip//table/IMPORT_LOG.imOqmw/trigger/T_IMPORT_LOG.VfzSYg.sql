create trigger T_IMPORT_LOG
  before insert
  on IMPORT_LOG
  for each row
  DECLARE  -- local variables here 
BEGIN  SELECT G_IMPORT_LOG.NEXTVAL INTO :NEW.ID FROM DUAL; 
END T_IMPORT_LOG;




/

