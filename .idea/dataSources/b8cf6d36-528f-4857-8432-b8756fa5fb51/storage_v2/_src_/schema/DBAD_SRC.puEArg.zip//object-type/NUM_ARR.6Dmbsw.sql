create TYPE            "NUM_ARR"                                          is table of number
/

