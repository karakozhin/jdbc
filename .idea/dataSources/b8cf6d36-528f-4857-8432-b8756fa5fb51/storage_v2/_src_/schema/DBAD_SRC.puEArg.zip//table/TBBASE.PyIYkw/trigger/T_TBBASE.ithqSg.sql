create trigger T_TBBASE
  before insert
  on TBBASE
  for each row
  declare
  -- local variables here
begin
  select g_tbbase.nextval into :new.id from dual;
end T_TBBASE;


/

