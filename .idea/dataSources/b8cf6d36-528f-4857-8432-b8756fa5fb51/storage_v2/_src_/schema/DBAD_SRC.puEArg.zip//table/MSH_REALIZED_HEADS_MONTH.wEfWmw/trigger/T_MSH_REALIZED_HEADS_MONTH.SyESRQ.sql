create trigger T_MSH_REALIZED_HEADS_MONTH
  before insert
  on MSH_REALIZED_HEADS_MONTH
  for each row
  DECLARE
  BEGIN  SELECT G_MSH_REALIZED_HEADS_MONTH.NEXTVAL INTO :NEW.ID FROM DUAL;
  END T_MSH_REALIZED_HEADS_MONTH;
  --------End Create trigger--------------------------
/

