create procedure P_NORMALIZE_M_TRANSPORT_NEXT IS

new_row m_transport%ROWTYPE;
BEGIN
  FOR i IN (
      select
       f1,
       f2,
       f3,
       f4,
       f5,
       f6,
       f8,
       f10,
       f11,
       f12,
       f13,
       f16,
       f17,
       f30,
       f41,
       f55,
       NN
       FROM dbad_src.m_transport t WHERE t.import_log_id IN (11539,11538,11537,11536,11535)
       )
    LOOP
         new_row:= NULL;
         new_row.f1 := i.f1;
         new_row.f2 := i.f2;
         new_row.f3 := i.f3;
         new_row.f4 := i.f4;
         new_row.f5 := i.f5;
         new_row.f6 := i.f6;
         new_row.f8 := i.f8;
         new_row.f10 := i.f10;
         new_row.f11 := i.f11;
         new_row.f12 := i.f12;
         new_row.f13 := i.f13;
         new_row.f16 := i.f16;
         new_row.f17 := i.f17;
         new_row.f30 := i.f30;
         new_row.f41 := i.f41;
         new_row.f55 := i.f55;
         new_row.nn := i.nn;
         new_row.replace_number :=0;

         BEGIN
            SELECT id INTO new_row.produced_year_interval FROM produced_year_interval WHERE init<= (extract(year from sysdate) - i.f13) AND (extract(year from sysdate) - i.f13)<= FINAL;
         EXCEPTION
            WHEN OTHERS THEN
            new_row.produced_year_interval := 5;
         END;
         BEGIN
            SELECT our_kato_id INTO new_row.kato FROM idnumber_kato WHERE REGEXP_LIKE(TRIM(i.F2), regexp);
         EXCEPTION
            WHEN OTHERS THEN
            new_row.kato := 18;
         END;
         BEGIN
            SELECT ID INTO new_row.volume_interval FROM volume_interval WHERE init<=i.f8  AND i.f8<=FINAL;
         EXCEPTION
            WHEN OTHERS THEN
            new_row.volume_interval := 8;
         END;
         BEGIN
            SELECT id INTO new_row.car_type FROM avto_type WHERE LOWER(name) LIKE LOWER(i.f11);
         EXCEPTION
            WHEN OTHERS THEN
            new_row.car_type := 3;
         END;
         BEGIN
            SELECT ID INTO new_row.fuel_type FROM fuel_type WHERE LOWER(name_ru) LIKE LOWER(i.f16);
         EXCEPTION
            WHEN OTHERS THEN
            new_row.owner := 3;
         END;
         BEGIN
            SELECT ID INTO new_row.owner FROM owner WHERE LOWER(name_ru) LIKE LOWER(i.f17);
         EXCEPTION
            WHEN OTHERS THEN
            new_row.owner := 3;
         END;
         BEGIN
            SELECT ID INTO new_row.card_status FROM card_status WHERE LOWER(name) LIKE LOWER(i.f41);
         EXCEPTION
            WHEN OTHERS THEN
            new_row.card_status := 3;
         END;

         BEGIN
            INSERT INTO m_transport VALUES new_row;
         EXCEPTION
         WHEN OTHERS THEN
            SELECT replace_number INTO new_row.replace_number FROM m_transport WHERE nn = new_row.nn;
            new_row.replace_number := new_row.replace_number + 1;
            UPDATE m_transport SET ROW = new_row WHERE NN = new_row.NN AND f1 <= new_row.f1;
         END;
      END LOOP;
      COMMIT;
end P_NORMALIZE_M_TRANSPORT_NEXT;
/

