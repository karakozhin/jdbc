create view IMPORT_MVD_TRANSPORT_VIEW as
  SELECT import_log.id, import_log.source_description,COUNT(*) FROM mvd_transport m join import_log on import_log.id = m.import_log_id group by import_log.id, import_log.source_description order by count(*)
--SELECT COUNT(*) FROM mvd_transport
/

