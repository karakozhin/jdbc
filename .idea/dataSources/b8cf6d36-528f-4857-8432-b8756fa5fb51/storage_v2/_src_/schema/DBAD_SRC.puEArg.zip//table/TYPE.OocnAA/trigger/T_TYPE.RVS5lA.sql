create trigger T_TYPE
  before insert
  on TYPE
  for each row
  DECLARE
  -- local variables here
BEGIN
  SELECT G_TYPE.NEXTVAL INTO :NEW.ID FROM DUAL;

END T_TYPE;



/

