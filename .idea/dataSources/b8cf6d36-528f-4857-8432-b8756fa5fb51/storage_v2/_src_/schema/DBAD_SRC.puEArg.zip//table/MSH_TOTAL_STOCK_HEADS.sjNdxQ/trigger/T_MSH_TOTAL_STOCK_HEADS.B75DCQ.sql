create trigger T_MSH_TOTAL_STOCK_HEADS
  before insert
  on MSH_TOTAL_STOCK_HEADS
  for each row
  DECLARE
  BEGIN  SELECT G_MSH_TOTAL_STOCK_HEADS.NEXTVAL INTO :NEW.ID FROM DUAL;
  END T_MSH_TOTAL_STOCK_HEADS;
  --------End Create trigger--------------------------
/

