create trigger T_NK_PR2_9
  before insert
  on NK_PR2_9
  for each row
  DECLARE
  BEGIN  SELECT G_nk_pr2_9.NEXTVAL INTO :NEW.ID FROM DUAL;
  END T_nk_pr2_9;


/

