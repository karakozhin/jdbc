create procedure P_NORMALIZEtestNew is
 v_src_id number;
 v_operation_date date;
 v_print_srts_date date;
 v_avto_type varchar2(50);
 v_avto_type_id number;
 cursor mvd_transport_cursor1 is select t.src_id from dbad_trg.mvd_transport t;
 CURSOR mvd_transport_cursor2 is select r.f1, r.f55, trim(r.f11) FROM dbad_src.mvd_transport r where r.id=v_src_id;
 cursor avto_type_cursor is  select id from dbad_trg.avto_type where trim(name)=v_avto_type;

 pragma autonomous_transaction;
begin
  open mvd_transport_cursor1;
   loop
     fetch mvd_transport_cursor1 into v_src_id;
      EXIT WHEN mvd_transport_cursor1%NOTFOUND;
       open mvd_transport_cursor2;
       fetch mvd_transport_cursor2 into v_operation_date,v_print_srts_date,v_avto_type;
       if v_avto_type is null then
         v_avto_type_id:=3;
       else
         open avto_type_cursor;
         fetch avto_type_cursor into v_avto_type_id;
         if v_avto_type_id is null then
           v_avto_type_id:=3333;
         end if;
         close avto_type_cursor;  
       end if; 
       if v_operation_date is null then
         v_operation_date:=to_date('01.01.1333','DD.MM.YYYY');
       end if;
       if v_print_srts_date is null then
         v_print_srts_date:=to_date('01.01.1333','DD.MM.YYYY');
       end if;
      close mvd_transport_cursor2;

     UPDATE dbad_trg.mvd_transport mvd SET mvd.operation_date=v_operation_date, mvd.print_date_srts=v_print_srts_date, mvd.avto_type_id=v_avto_type_id where mvd.src_id=v_src_id;
    /* INSERT INTO dbad_src.test(id) values(v_src_id);*/
     commit;

   end loop;
  close mvd_transport_cursor1;

end P_NORMALIZEtestNew;
/

