create trigger T_NK_PR16
  before insert
  on NK_PR16
  for each row
  DECLARE  BEGIN  SELECT G_NK_PR16.NEXTVAL INTO :NEW.ID FROM DUAL;  END T_NK_PR16;


/

