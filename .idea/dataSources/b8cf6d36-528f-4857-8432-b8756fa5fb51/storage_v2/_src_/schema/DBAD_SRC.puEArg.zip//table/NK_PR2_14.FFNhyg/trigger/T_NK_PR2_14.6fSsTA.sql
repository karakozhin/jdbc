create trigger T_NK_PR2_14
  before insert
  on NK_PR2_14
  for each row
  DECLARE
  BEGIN  SELECT G_nk_pr2_14.NEXTVAL INTO :NEW.ID FROM DUAL;
  END T_nk_pr2_14;


/

