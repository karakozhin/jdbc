create trigger T_KTK_ECOM_2014
  before insert
  on KTK_ECOM_2014
  for each row
  DECLARE
  BEGIN  SELECT G_ktk_ecom_2014.NEXTVAL INTO :NEW.ID FROM DUAL;
  END T_ktk_ecom_2014;


/

