create trigger T_LEARNING_4
  before insert
  on LEARNING_4
  for each row
  DECLARE
  BEGIN  SELECT G_LEARNING_4.NEXTVAL INTO :NEW.ID FROM DUAL;
  END T_LEARNING_4;


/

