create procedure P_NORMALIZE_NK_PR12 is

cursor cur_get_info IS
select
  *
FROM nk_pr12 where nk_pr12.is_normalized=0
FOR UPDATE OF nk_pr12.IS_NORMALIZED;

begin


      FOR i IN cur_get_info LOOP


      INSERT INTO DBAD_TRG.NK_PR12(
      iin,
      bin,
      kod_obl_atnk,
      kod_raion_atnk,
      tip_subj,
      podohod_nalog_yl,
      podohod_nalog_ip,
      soc_nalog,
      nalog_na_stoimos,
      akzic,
      zemel_nalog,
      podohod_nalog_byplat,
      nalog_na_dobyh,
      rentny_nalog_export,
      sbor_auksion,
      sbor_na_proesd_avto_respub,
      sbor_na_proesd_avto_mest,
      plata_sa_rasmeh_reklam_respub,
      plata_sa_rasmeh__reklam_mest,
      nalog_na_igor_bis,
      nalog_na_imuch,
      zem_nalog,
      nalog_na_trans,
      org_proved_loterei,
      plata_vod_resurs,
      plata_les,
      plata_radiohastot_ispol,
      ispol_sydohod_vod_put,
      ispol_zhivot_mirom,
      ispol_prirod_territor_respub,
      ispol_zhemel_resursi,
      zagryznenie_ymissii,
      plat_istorich_zatrat,
      sbor_gos_registr_ip,
      lizen_sbor,
      sbor_gos_registr_yl,
      sbor_gos_regiszalog_imuch,
      sbor_gos_radelek_sred,
      sbor_rasr_radiohastor,
      sbor_gos_registrprizep,
      sbor_gosredac_lek_sred,
      sbor_gos_reg_nedvizh_imuh,
      sbor_gos_reg_avtor_prava,
      sbor_postan_smi,
      proh_nalog_postup_resp,
      proh_nalog_mest_budzh,
      konsul_sbor,
      gosposh_oruzhie,
      gosposh_apostila,
      gosposh_vodit_udost,
      gosposh_mech_trans_sred,
      gosposh_gos_nomera,
      gosposh_redkie_zhivot,
      gosposh_intell_sobstv,
      gosposh_v_sud_isk,
      postupe_poter_leschoza,
      plata_o_nedrah,
      postup_realiz_tovara,
      postup_ot_uderzhanii_zp,
      nalog_postup_respub,
      nalog_postup_mest_bud,
      prohie_postup,
      soc_otcheslen,
      import_log_id,
      src_id
      )
      VALUES(
          i.iin,
  i.bin,
  i.kod_obl_atnk,
  i.kod_raion_atnk                ,
  i.tip_subj                      ,
  to_number(replace(replace(i.podohod_nalog_yl, ' ', ''),'.',',')),
  to_number(replace(replace(i.podohod_nalog_ip, ' ', ''),'.',',')),
  to_number(replace(replace(i.soc_nalog, ' ', ''),'.',',')),
  to_number(replace(replace(i.nalog_na_stoimos, ' ', ''),'.',',')),
  to_number(replace(replace(i.akzic, ' ', ''),'.',',')),
  to_number(replace(replace(i.zemel_nalog, ' ', ''),'.',',')),
  to_number(replace(replace(i.podohod_nalog_byplat, ' ', ''),'.',',')),
  to_number(replace(replace(i.nalog_na_dobyh, ' ', ''),'.',',')),
  to_number(replace(replace(i.rentny_nalog_export, ' ', ''),'.',',')),
  to_number(replace(replace(i.sbor_auksion, ' ', ''),'.',',')),
  to_number(replace(replace(i.sbor_na_proesd_avto_respub, ' ', ''),'.',',')),
  to_number(replace(replace(i.sbor_na_proesd_avto_mest, ' ', ''),'.',',')),
  to_number(replace(replace(i.plata_sa_rasmeh_reklam_respub, ' ', ''),'.',',')),
  to_number(replace(replace(i.plata_sa_rasmeh__reklam_mest, ' ', ''),'.',',')),
  to_number(replace(replace(i.nalog_na_igor_bis, ' ', ''),'.',',')),
  to_number(replace(replace(i.nalog_na_imuch, ' ', ''),'.',',')),
  to_number(replace(replace(i.zem_nalog, ' ', ''),'.',',')),
  to_number(replace(replace(i.nalog_na_trans, ' ', ''),'.',',')),
  to_number(replace(replace(i.org_proved_loterei, ' ', ''),'.',',')),
  to_number(replace(replace(i.plata_vod_resurs, ' ', ''),'.',',')),
  to_number(replace(replace(i.plata_les, ' ', ''),'.',',')),
  to_number(replace(replace(i.plata_radiohastot_ispol, ' ', ''),'.',',')),
  to_number(replace(replace(i.ispol_sydohod_vod_put, ' ', ''),'.',',')),
  to_number(replace(replace(i.ispol_zhivot_mirom, ' ', ''),'.',',')),
  to_number(replace(replace(i.ispol_prirod_territor_respub, ' ', ''),'.',',')),
  to_number(replace(replace(i.ispol_zhemel_resursi, ' ', ''),'.',',')),
  to_number(replace(replace(i.zagryznenie_ymissii, ' ', ''),'.',',')),
  to_number(replace(replace(i.plat_istorich_zatrat, ' ', ''),'.',',')),
  to_number(replace(replace(i.sbor_gos_registr_ip, ' ', ''),'.',',')),
  to_number(replace(replace(i.lizen_sbor, ' ', ''),'.',',')),
  to_number(replace(replace(i.sbor_gos_registr_yl, ' ', ''),'.',',')),
  to_number(replace(replace(i.sbor_gos_regiszalog_imuch, ' ', ''),'.',',')),
  to_number(replace(replace(i.sbor_gos_radelek_sred, ' ', ''),'.',',')),
  to_number(replace(replace(i.sbor_rasr_radiohastor, ' ', ''),'.',',')),
  to_number(replace(replace(i.sbor_gos_registrprizep, ' ', ''),'.',',')),
  to_number(replace(replace(i.sbor_gosredac_lek_sred, ' ', ''),'.',',')),
  to_number(replace(replace(i.sbor_gos_reg_nedvizh_imuh, ' ', ''),'.',',')),
  to_number(replace(replace(i.sbor_gos_reg_avtor_prava, ' ', ''),'.',',')),
  to_number(replace(replace(i.sbor_postan_smi, ' ', ''),'.',',')),
  to_number(replace(replace(i.proh_nalog_postup_resp, ' ', ''),'.',',')),
  to_number(replace(replace(i.proh_nalog_mest_budzh, ' ', ''),'.',',')),
  to_number(replace(replace(i.konsul_sbor, ' ', ''),'.',',')),
  to_number(replace(replace(i.gosposh_oruzhie, ' ', ''),'.',',')),
  to_number(replace(replace(i.gosposh_apostila, ' ', ''),'.',',')),
  to_number(replace(replace(i.gosposh_vodit_udost, ' ', ''),'.',',')),
  to_number(replace(replace(i.gosposh_mech_trans_sred, ' ', ''),'.',',')),
  to_number(replace(replace(i.gosposh_gos_nomera, ' ', ''),'.',',')),
  to_number(replace(replace(i.gosposh_redkie_zhivot, ' ', ''),'.',',')),
  to_number(replace(replace(i.gosposh_intell_sobstv, ' ', ''),'.',',')),
  to_number(replace(replace(i.gosposh_v_sud_isk, ' ', ''),'.',',')),
  to_number(replace(replace(i.postupe_poter_leschoza, ' ', ''),'.',',')),
  to_number(replace(replace(i.plata_o_nedrah, ' ', ''),'.',',')),
  to_number(replace(replace(i.postup_realiz_tovara, ' ', ''),'.',',')),
  to_number(replace(replace(i.postup_ot_uderzhanii_zp, ' ', ''),'.',',')),
  to_number(replace(replace(i.nalog_postup_respub, ' ', ''),'.',',')),
  to_number(replace(replace(i.nalog_postup_mest_bud, ' ', ''),'.',',')),
  to_number(replace(replace(i.prohie_postup, ' ', ''),'.',',')),
  i.soc_otcheslen,
  i.import_log_id,
  i.id
 );






      UPDATE nk_pr12
      SET nk_pr12.IS_NORMALIZED = 1
      WHERE CURRENT OF cur_get_info;

      END LOOP;

     COMMIT;

end P_NORMALIZE_NK_PR12;
/

