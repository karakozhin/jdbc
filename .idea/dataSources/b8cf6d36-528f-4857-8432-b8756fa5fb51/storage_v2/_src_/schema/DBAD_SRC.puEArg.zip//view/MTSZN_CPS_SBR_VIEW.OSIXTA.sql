create view MTSZN_CPS_SBR_VIEW as
  select
    p_rnn, vo, qrtr, amount, emp_num,
    CASE
        -- Малые предприятия
        WHEN emp_num <= 5  THEN '105'
        WHEN emp_num <= 10 THEN '110'
        WHEN emp_num <= 20 THEN '120'
        WHEN emp_num <= 30 THEN '130'
        WHEN emp_num <= 40 THEN '140'
        WHEN emp_num <= 50 THEN '150'
        -- Средние предприятия
        WHEN emp_num <= 100 THEN '210'
        WHEN emp_num <= 150 THEN '215'
        WHEN emp_num <= 200 THEN '220'
        WHEN emp_num <= 250 THEN '225'
        -- Крупные предприятия
        WHEN emp_num <= 500  THEN '305'
        WHEN emp_num <= 1000 THEN '310'
        WHEN emp_num > 1000  THEN '311'
    END KRP --класс предприятия
FROM
(
 -- группируем по кварталам и юр. лицам
 SELECT P_RNN, QRTR, VO, SUM(TO_NUMBER(AMOUNT,'99999999999.99')) AMOUNT, COUNT(IIN) emp_num
 FROM
  (
   SELECT ID, P_RNN, IIN, AMOUNT, CONCAT (TO_CHAR(LAST_DATE, 'Q'), ' кв.') qrtr, CONCAT (TO_CHAR(LAST_DATE, 'YYYY'), ' г.') jahr, BIN_IIN,
    CASE WHEN VO='08' THEN '08' ELSE '01' END VO
    FROM MTSZN_CPS
  )
 where qrtr = '1 кв.' and jahr = '2012 г.'
 GROUP BY P_RNN, QRTR, VO
 ) main_tbl
 ORDER BY P_RNN, QRTR
/

