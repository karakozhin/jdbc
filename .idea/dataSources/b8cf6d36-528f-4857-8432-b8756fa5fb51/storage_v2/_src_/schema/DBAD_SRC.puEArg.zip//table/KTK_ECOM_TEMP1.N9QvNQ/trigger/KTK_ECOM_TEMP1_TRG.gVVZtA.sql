create trigger KTK_ECOM_TEMP1_TRG
  before insert
  on KTK_ECOM_TEMP1
  for each row
  begin
  if :new.id is null then
    select KTK_ECOM_TEMP1_seq.nextval into :new.id from dual;
  end if;
end;
/

