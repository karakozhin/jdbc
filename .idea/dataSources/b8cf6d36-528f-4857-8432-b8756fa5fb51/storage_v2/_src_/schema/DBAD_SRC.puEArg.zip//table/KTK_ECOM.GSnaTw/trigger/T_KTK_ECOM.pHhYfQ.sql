create trigger T_KTK_ECOM
  before insert
  on KTK_ECOM
  for each row
  DECLARE  
  BEGIN  SELECT G_KTK_ECOM.NEXTVAL INTO :NEW.ID FROM DUAL; 
  END T_KTK_ECOM;

/

