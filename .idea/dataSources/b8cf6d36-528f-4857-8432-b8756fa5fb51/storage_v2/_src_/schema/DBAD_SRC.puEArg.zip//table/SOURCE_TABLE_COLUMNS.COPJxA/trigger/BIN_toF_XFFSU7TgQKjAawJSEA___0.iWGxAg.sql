create trigger "BIN$toF/XFFSU7TgQKjAawJSEA==$0"
  before insert
  on SOURCE_TABLE_COLUMNS
  for each row
  DECLARE
  -- local variables here
BEGIN
  SELECT G_SOURCE_TABLE_COLUMNS.NEXTVAL INTO :NEW.ID FROM DUAL;

END T_SOURCE_TABLE_COLUMNS;



/

