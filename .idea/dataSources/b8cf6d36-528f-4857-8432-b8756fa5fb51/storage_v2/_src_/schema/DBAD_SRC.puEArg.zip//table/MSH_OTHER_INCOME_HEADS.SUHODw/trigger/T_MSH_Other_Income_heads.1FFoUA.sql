create trigger "T_MSH_Other_Income_heads"
  before insert
  on MSH_OTHER_INCOME_HEADS
  for each row
  DECLARE
  BEGIN  SELECT G_MSH_Other_Income_heads.NEXTVAL INTO :NEW.ID FROM DUAL;
  END T_MSH_Other_Income_heads;
/

