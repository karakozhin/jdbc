create trigger T_SEND_LOG
  before insert
  on SEND_LOG
  for each row
  declare
  -- local variables here
begin
  select g_SEND_LOG.nextval into :new.id from dual;
end T_SEND_LOG;


/

