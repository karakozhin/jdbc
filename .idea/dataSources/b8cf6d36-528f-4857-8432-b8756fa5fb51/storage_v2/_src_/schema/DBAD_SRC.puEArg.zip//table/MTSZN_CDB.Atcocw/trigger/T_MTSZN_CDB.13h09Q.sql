create trigger T_MTSZN_CDB
  before insert
  on MTSZN_CDB
  for each row
  DECLARE
  BEGIN  SELECT G_MTSZN_CDB.NEXTVAL INTO :NEW.ID FROM DUAL;
  END T_MTSZN_CDB;


/

