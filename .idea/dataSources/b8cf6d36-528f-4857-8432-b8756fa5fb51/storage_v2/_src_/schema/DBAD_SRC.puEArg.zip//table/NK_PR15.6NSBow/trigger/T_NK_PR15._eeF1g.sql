create trigger T_NK_PR15
  before insert
  on NK_PR15
  for each row
  DECLARE  BEGIN  SELECT G_NK_PR15.NEXTVAL INTO :NEW.ID FROM DUAL;  END T_NK_PR15;


/

