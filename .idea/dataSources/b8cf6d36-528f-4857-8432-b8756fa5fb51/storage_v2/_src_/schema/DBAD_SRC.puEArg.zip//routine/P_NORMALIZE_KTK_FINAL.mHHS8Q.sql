create procedure P_NORMALIZE_KTK_FINAL(IMP_LOG_ID IN NUMBER) is

period_kindlist_id number;

cursor cur_get_info IS
select
  ktk_flk.ID,
  ktk_flk.KATO,
  class_kato_level_codes.id as KATOID,
  ktk_flk.G33,
  class_tnved_level_codes.id as G33ID,
  ktk_flk.G11,
  ks1.id as G11ID,
  ktk_flk.G34,
  ks2.id as G34ID,
  ktk_flk.G011,
  class_sei_level_codes.id as G011ID,
  ktk_flk.STRAN,
  ks3.id as STRANID,
  ktk_flk.G251,
  class_kvt_level_codes.id as G251ID,
  ktk_flk.G38,
  ktk_flk.G315A,
  ktk_flk.G46,
  ktk_flk.G46_TG,
  ktk_flk.IMPORT_LOG_ID
FROM KTK_FLK,
class_kato_level_codes,
class_tnved_level_codes,
class_ks_level_codes  ks1,
class_ks_level_codes  ks2,
class_sei_level_codes,
class_ks_level_codes ks3,
class_kvt_level_codes
where
ktk_flk.KATO=class_kato_level_codes.level_code and
ktk_flk.G33=class_tnved_level_codes.level_code and
ktk_flk.G11=ks1.level_code and
ktk_flk.G34=ks2.level_code and
ktk_flk.G011=class_sei_level_codes.level_code and
ktk_flk.STRAN=ks3.level_code and
ktk_flk.G251=class_kvt_level_codes.level_code and KTK_FLK.IMPORT_LOG_ID=IMP_LOG_ID;

                                                                     
TYPE T_KTK_FLK_TAB  IS TABLE OF cur_get_info%ROWTYPE INDEX BY binary_integer;
l_info_list     T_KTK_FLK_TAB;
arr_acronym_id  num_arr;
cur_rec cur_get_info%rowtype;
space_id NUMBER:=1;
space_instance_id NUMBER:=2;
arr_dimension_id num_arr;
arr_item num_arr;
space_el_set_id number;
begin

SELECT PKL.id into period_kindlist_id
  FROM MDIC_PERIOD_KINDLIST@META_V2 PKL, MDIC_PERIOD@META_V2 P, MDIC_PERIOD_TYPE@META_V2 DP, IMPORT_LOG IL, REPORT_PERIODS RP
 WHERE PKL.PERIOD = P.PERIOD_ID and DP.PERIOD_TYPE_ID=4 and IL.Id=IMP_LOG_ID and IL.Report_Periods_Id=RP.Id and RP.DATA_BEGIN=P.DBEG
   AND PKL.KIND = DP.PERIOD_TYPE_ID;  

arr_item:=num_arr();
arr_item.EXTEND(7);
arr_acronym_id:=num_arr();
arr_acronym_id.EXTEND(7);
arr_acronym_id(1):=67;
arr_acronym_id(2):=146;
arr_acronym_id(3):=952; --arr_acronym_id(3):=876;
arr_acronym_id(4):=953; --arr_acronym_id(4):=875;
arr_acronym_id(5):=846;
arr_acronym_id(6):=1208; --arr_acronym_id(6):=12;
arr_acronym_id(7):=74;

open cur_get_info;
    loop
        fetch cur_get_info into cur_rec;
        exit when (cur_get_info%NOTFOUND AND l_info_list.count() <= 0);
        p_get_space_instance(arr_acronym_id,space_id,space_instance_id,arr_dimension_id);
        
        arr_item(1):=TO_NUMBER(cur_rec.KATOID);
        arr_item(2):=TO_NUMBER(cur_rec.G33ID);
        arr_item(3):=TO_NUMBER(cur_rec.G11ID);
        arr_item(4):=TO_NUMBER(cur_rec.G34ID);
        arr_item(5):=TO_NUMBER(cur_rec.G011ID);
        arr_item(6):=TO_NUMBER(cur_rec.STRANID);
        arr_item(7):=TO_NUMBER(cur_rec.G251ID);
        
        p_get_space_element_set(arr_dimension_id, arr_item ,space_id, space_el_set_id);

        insert into ktk_final(id,ktk_flk_id,import_log_id,space_element_set_id,csi_instance_id,reporting_period,value)
        values(g_ktk_final.nextval, cur_rec.id, cur_rec.import_log_id, space_el_set_id, 2975, period_kindlist_id, TO_NUMBER(cur_rec.g38));

        insert into ktk_final(id,ktk_flk_id,import_log_id,space_element_set_id,csi_instance_id,reporting_period,value)
        values(g_ktk_final.nextval, cur_rec.id, cur_rec.import_log_id, space_el_set_id, 2974, period_kindlist_id, TO_NUMBER(cur_rec.g315A));

        insert into ktk_final(id,ktk_flk_id,import_log_id,space_element_set_id,csi_instance_id,reporting_period,value)
        values(g_ktk_final.nextval, cur_rec.id, cur_rec.import_log_id, space_el_set_id, 2973, period_kindlist_id, TO_NUMBER(cur_rec.g46));

        insert into ktk_final(id,ktk_flk_id,import_log_id,space_element_set_id,csi_instance_id,reporting_period,value)
        values(g_ktk_final.nextval, cur_rec.id, cur_rec.import_log_id, space_el_set_id, 2972, period_kindlist_id, TO_NUMBER(cur_rec.g46_TG));

        exit when cur_get_info%NOTFOUND;
    end loop;
    close cur_get_info;
    commit;


end P_NORMALIZE_KTK_FINAL;
/

