create trigger T_NK_PR5
  before insert
  on NK_PR5
  for each row
  DECLARE  BEGIN  SELECT G_NK_PR5.NEXTVAL INTO :NEW.ID FROM DUAL;  END T_NK_PR5;


/

