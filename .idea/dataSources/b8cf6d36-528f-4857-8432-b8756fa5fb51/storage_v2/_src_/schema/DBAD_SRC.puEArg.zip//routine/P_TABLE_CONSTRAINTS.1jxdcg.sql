create procedure P_Table_Constraints(Table1 in string, Table2 in string, Tab1_Id in number, Tab2_Id in number) is
begin
  dbms_output.put_line(table1);
end P_Table_Constraints;


/

