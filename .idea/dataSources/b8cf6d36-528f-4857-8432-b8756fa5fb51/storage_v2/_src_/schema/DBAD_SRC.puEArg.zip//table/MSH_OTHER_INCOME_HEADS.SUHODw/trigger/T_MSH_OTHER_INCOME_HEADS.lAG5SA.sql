create trigger T_MSH_OTHER_INCOME_HEADS
  before insert
  on MSH_OTHER_INCOME_HEADS
  for each row
  DECLARE
  BEGIN  SELECT G_MSH_OTHER_INCOME_HEADS.NEXTVAL INTO :NEW.ID FROM DUAL;
  END T_MSH_OTHER_INCOME_HEADS;
  --------End Create trigger--------------------------
/

