create trigger "T_MSH_disposals_heads_month"
  before insert
  on MSH_DISPOSALS_HEADS_MONTH
  for each row
  DECLARE
  BEGIN  SELECT G_MSH_disposals_heads_month.NEXTVAL INTO :NEW.ID FROM DUAL;
  END T_MSH_disposals_heads_month;
/

