create trigger T_LEARNING_5
  before insert
  on LEARNING_5
  for each row
  DECLARE
  BEGIN  SELECT G_LEARNING_5.NEXTVAL INTO :NEW.ID FROM DUAL;
  END T_LEARNING_5;


/

